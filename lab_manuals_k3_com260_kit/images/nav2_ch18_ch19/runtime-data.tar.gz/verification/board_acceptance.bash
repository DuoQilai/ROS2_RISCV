#!/usr/bin/env bash
set -eo pipefail
run=$1
[[ $run =~ ^[[:alnum:]_-]+$ ]]
repo="$HOME/ROS2_RISCV_COM260_CH18_CH19"
workspace="$HOME/ros2_course_com260_ch18_ch19_ws"
out="$workspace/runs/$run"
mkdir -p "$out"
exec > >(tee "$out/board-build-and-examples.log") 2>&1
source "$workspace/board-env.bash"
printf 'RUN_ID=%s HOST=COM260\n' "$run"
date -u
uname -m
tr '\0' '\n' < /proc/device-tree/model
python3 "$workspace/fingerprint.py" "$repo" "$out/source-local.json" "$out/source-board-before.json"
bash "$repo/setup_course_k3_com260_kit.sh" --build-ch18
bash "$repo/setup_course_k3_com260_kit.sh" --build-ch19
source "$HOME/.config/ros2-course-com260-ch18-ch19/env.bash"
cd "$out"
for package in grid_path_planner hybrid_astar_planner path_optimizer dwa_planner rpp_controller; do
  printf '\n$ ros2 run %s %s\n' "$package" "$package"
  ros2 run "$package" "$package"
done
printf '\nInvalid speed must exit 2\n'
if ros2 run dwa_planner dwa_controller --ros-args -p max_speed:=-1.0; then exit 1; else code=$?; fi
[[ $code == 2 ]]
printf '\nMissing inputs must stop and exit 1\n'
if ROS_DOMAIN_ID=183 ros2 run dwa_planner dwa_controller --ros-args -p timeout:=1.0; then exit 1; else code=$?; fi
[[ $code == 1 ]]
python3 "$workspace/fingerprint.py" "$repo" "$out/source-local.json" "$out/source-board-after.json"
printf '\nCOM260_BUILD_EXAMPLES_AND_NEGATIVE_INPUTS_PASSED\n'

import hashlib
import json
from pathlib import Path
import sys

root, manifest, output = map(Path, sys.argv[1:])
expected = json.loads(manifest.read_text())
actual = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}
changed = [name for name in expected if actual[name] != expected[name]]
output.write_text(json.dumps(actual, indent=2))
assert not changed, changed
print(f'SOURCE_SHA256_MATCH files={len(actual)}', flush=True)

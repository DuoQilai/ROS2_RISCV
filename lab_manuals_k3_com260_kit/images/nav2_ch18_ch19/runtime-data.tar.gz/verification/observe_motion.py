import json
import os
import re
from datetime import datetime, timezone
import math
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

import rclpy
from rclpy.qos import qos_profile_sensor_data
from rclpy.time import Time
from nav_msgs.msg import Odometry, Path as RosPath
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer, TransformListener

mode, name = sys.argv[1:3]
x, y = map(float, sys.argv[3:5])
root = Path.home() / 'ros2_course_com260_ch18_ch19_ws'
run_id = os.environ.get('COURSE_EVIDENCE_RUN', 'development')
assert re.fullmatch(r'[A-Za-z0-9_-]+', run_id)
out = root / ('development' if run_id == 'development' else 'runs/' + run_id) / name
out.mkdir(parents=True, exist_ok=True)
rclpy.init()
node = rclpy.create_node('planning_acceptance')
buffer = Buffer()
listener = TransformListener(buffer, node)
odom, scans, plans, tracking = [], [], [], []
last_forwarded = None
relay_enabled = True
relay = node.create_publisher(LaserScan, '/acceptance_scan', qos_profile_sensor_data) if mode == 'dwa-stale' else None
def on_scan(message):
    global last_forwarded
    scans.append((time.monotonic(), min((r for r in message.ranges if math.isfinite(r) and r >= message.range_min), default=math.inf)))
    if relay and relay_enabled:
        relay.publish(message)
        last_forwarded = time.monotonic()
def on_odom(message):
    stamp = time.monotonic()
    odom.append((stamp, message))
    if not plans or len(plans[-1]) < 2:
        return
    try:
        transform = buffer.lookup_transform('map', 'odom', Time()).transform
    except Exception:
        return
    q = transform.rotation
    yaw = math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
    p = message.pose.pose.position
    point = (transform.translation.x+p.x*math.cos(yaw)-p.y*math.sin(yaw),
             transform.translation.y+p.x*math.sin(yaw)+p.y*math.cos(yaw))
    nearest = math.inf
    for a,b in zip(plans[-1],plans[-1][1:]):
        dx,dy = b[0]-a[0],b[1]-a[1]
        squared = dx*dx+dy*dy
        factor = 0 if squared == 0 else max(0,min(1,((point[0]-a[0])*dx+(point[1]-a[1])*dy)/squared))
        nearest = min(nearest,math.dist(point,(a[0]+factor*dx,a[1]+factor*dy)))
    tracking.append((stamp,*point,nearest))
node.create_subscription(Odometry, '/odom', on_odom, qos_profile_sensor_data)
node.create_subscription(LaserScan, '/scan', on_scan, qos_profile_sensor_data)
node.create_subscription(RosPath, '/plan', lambda m: plans.append([(p.pose.position.x, p.pose.position.y) for p in m.poses]), 10)

def spin(seconds):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        rclpy.spin_once(node, timeout_sec=0.03)

spin(3)
assert odom, 'No odometry'
odom.clear()
command = ['ros2', 'run', 'navigation_client_cpp', 'bt_navigator_client', '--ros-args', '-p', 'use_sim_time:=true', '-p', f'x:={x}', '-p', f'y:={y}']
if mode.startswith('dwa'):
    command = ['ros2', 'run', 'dwa_planner', 'dwa_controller', '--ros-args', '-p', 'use_sim_time:=true', '-p', 'timeout:=100.0']
if mode == 'dwa-stale':
    command += ['-r', 'scan:=/acceptance_scan']
begin = time.monotonic()
start_utc = datetime.now(timezone.utc).isoformat()
print('RUN_ID=' + run_id + ' COMMAND=' + ' '.join(command), flush=True)
with (out / 'client.log').open('w') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    if mode.startswith('dwa'):
        spin(3)
        with (out / 'planner.log').open('w') as planner_log:
            planner = subprocess.Popen(['ros2', 'run', 'global_planner_client', 'global_planner_client', '--ros-args', '-p', 'use_sim_time:=true', '-p', f'goal_x:={x}', '-p', f'goal_y:={y}'], stdout=planner_log, stderr=subprocess.STDOUT)
            while planner.poll() is None:
                rclpy.spin_once(node, timeout_sec=0.03)
            if planner.returncode != 0:
                os.killpg(process.pid, signal.SIGINT)
                spin(2)
                process.wait(timeout=10)
                raise RuntimeError('C++ planner failed')
    signaled = False
    while process.poll() is None and time.monotonic() - begin < 150:
        rclpy.spin_once(node, timeout_sec=0.03)
        if mode == 'dwa-stale' and time.monotonic() - begin > 9:
            relay_enabled = False
        signal_after = 16 if mode == 'dwa-stale' else 9
        if mode in ['dwa-cancel','dwa-term','dwa-stale'] and time.monotonic() - begin > signal_after and not signaled:
            os.killpg(process.pid, signal.SIGTERM if mode == 'dwa-term' else signal.SIGINT)
            signaled = True
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGINT)
        spin(5)
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGKILL)
    code = process.wait()
spin(3)
transform = buffer.lookup_transform('map', 'base_link', Time()).transform.translation
position = [transform.x, transform.y]
recent = [m for t, m in odom if t > time.monotonic() - 2]
stopped = bool(recent) and all(abs(m.twist.twist.linear.x) < .02 and abs(m.twist.twist.angular.z) < .03 for m in recent)
points = [(m.pose.pose.position.x, m.pose.pose.position.y) for _, m in odom]
error = math.hypot(position[0] - x, position[1] - y)
result = dict(run_id=run_id,start_utc=start_utc,end_utc=datetime.now(timezone.utc).isoformat(),name=name, mode=mode, target=[x,y], exit=code, duration_s=time.monotonic()-begin,
              map_base_xy=position, error_m=error, odom_samples=len(odom), stopped=stopped,
              travelled_m=sum(math.dist(a,b) for a,b in zip(points,points[1:])),
              minimum_scan_m=min((r for t,r in scans if t > begin), default=None),
              path_messages=len(plans), path_points=len(plans[-1]) if plans else 0)
negative = mode in ['dwa-cancel','dwa-term','dwa-stale']
result['passed'] = stopped and len(odom) > 20 and ((negative and code != 0) or (not negative and code == 0 and error <= .25))
if mode == 'dwa-stale':
    gap = [m for t,m in odom if last_forwarded and last_forwarded + 1.5 < t < begin + 15]
    result['stopped_during_scan_gap'] = bool(gap) and all(abs(m.twist.twist.linear.x)<.02 and abs(m.twist.twist.angular.z)<.03 for m in gap)
    result['passed'] &= result['stopped_during_scan_gap'] and result['travelled_m'] > .05
if tracking:
    result['tracking_rms_m'] = math.sqrt(statistics.mean(row[3]**2 for row in tracking))
    result['tracking_peak_m'] = max(row[3] for row in tracking)
    result['tracking_frame'] = 'map, latest map->odom TF and nearest segment of latest /plan'
if 'corridor' in name:
    lateral = [abs(py) for px,py in points if 0<=px<=2]
    result['maximum_lateral_m'] = max(lateral,default=math.inf)
    result['minimum_wall_clearance_m'] = .4-result['maximum_lateral_m']-.22
    result['passed'] &= result['minimum_wall_clearance_m']>0 and points[-1][0]>2
if 'obstacle' in name or 'box' in name:
    result['minimum_box_clearance_m'] = min(math.hypot(max(.65-px,0,px-.95),max(-.15-py,0,py-.15))-.22 for px,py in points)
    result['passed'] &= result['minimum_box_clearance_m']>0
(out / 'tracking.csv').write_text('monotonic,map_x,map_y,error_m\n'+''.join(','.join(map(str,row))+'\n' for row in tracking))
(out / 'metrics.json').write_text(json.dumps(result, indent=2))
(out / 'odom.csv').write_text('monotonic,x,y,vx,wz\n' + ''.join(f'{t},{m.pose.pose.position.x},{m.pose.pose.position.y},{m.twist.twist.linear.x},{m.twist.twist.angular.z}\n' for t,m in odom))
(out / 'paths.json').write_text(json.dumps(plans))
print((out / 'client.log').read_text(), flush=True)
print(json.dumps(result), flush=True)
node.destroy_node()
rclpy.shutdown()
sys.exit(0 if result['passed'] else 1)

import json
import os
import re
import math
from pathlib import Path
import subprocess
import sys
import time
import statistics
import rclpy
from rclpy.action import ActionClient
from nav2_msgs.action import ComputePathToPose
from nav2_msgs.srv import GetCostmap

name = sys.argv[1]
target = tuple(map(float, sys.argv[2:4])) if len(sys.argv) == 4 else (2.0, -1.0)
run_id = os.environ.get('COURSE_EVIDENCE_RUN', 'development')
assert re.fullmatch(r'[A-Za-z0-9_-]+', run_id)
out = Path.home() / 'ros2_course_com260_ch18_ch19_ws' / ('development' if run_id == 'development' else 'runs/' + run_id) / name
out.mkdir(parents=True, exist_ok=True)
command = ['ros2','run','global_planner_client','global_planner_client','--ros-args','-p','use_sim_time:=true','-p',f'goal_x:={target[0]}','-p',f'goal_y:={target[1]}']
cpp = subprocess.run(command, capture_output=True, text=True, timeout=50)
(out/'client.log').write_text(cpp.stdout+cpp.stderr)
assert cpp.returncode == 0, cpp.stderr
rclpy.init()
node = rclpy.create_node('planner_acceptance')
action = ActionClient(node, ComputePathToPose, '/compute_path_to_pose')
costmap = node.create_client(GetCostmap, '/global_costmap/get_costmap')
assert action.wait_for_server(timeout_sec=15) and costmap.wait_for_service(timeout_sec=15)
goal = ComputePathToPose.Goal()
goal.start.header.frame_id = goal.goal.header.frame_id = 'map'
goal.start.pose.orientation.w = goal.goal.pose.orientation.w = 1.0
goal.goal.pose.position.x, goal.goal.pose.position.y = target
goal.use_start = True
goal.planner_id = 'GridBased'
timings = []
for trial in range(5):
    begin = time.perf_counter()
    sent = action.send_goal_async(goal)
    rclpy.spin_until_future_complete(node,sent,timeout_sec=15)
    assert sent.done() and sent.result().accepted
    future = sent.result().get_result_async()
    rclpy.spin_until_future_complete(node,future,timeout_sec=30)
    assert future.done()
    reply = future.result()
    assert reply.status == 4
    timings.append((time.perf_counter()-begin)*1000)
request = costmap.call_async(GetCostmap.Request())
rclpy.spin_until_future_complete(node,request,timeout_sec=10)
grid = request.result().map
meta = grid.metadata
points = [(p.pose.position.x,p.pose.position.y) for p in reply.result.path.poses]
costs = []
for a,b in zip(points,points[1:]):
    steps = max(1,math.ceil(math.dist(a,b)/(meta.resolution/2)))
    for i in range(steps+1):
        x,y = (a[j]+i/steps*(b[j]-a[j]) for j in (0,1))
        gx,gy = math.floor((x-meta.origin.position.x)/meta.resolution), math.floor((y-meta.origin.position.y)/meta.resolution)
        costs.append(grid.data[gy*meta.size_x+gx] if 0<=gx<meta.size_x and 0<=gy<meta.size_y else 255)
headings = [math.atan2(b[1]-a[1],b[0]-a[0]) for a,b in zip(points,points[1:]) if math.dist(a,b)>1e-8]
turn = sum(abs(math.atan2(math.sin(b-a),math.cos(b-a))) for a,b in zip(headings,headings[1:]))
error = math.dist(points[-1],target) if points else math.inf
result = dict(run_id=run_id,name=name,target=target,cpp_exit=cpp.returncode,action_status=reply.status,points=len(points),
              length_m=sum(math.dist(a,b) for a,b in zip(points,points[1:])),turn_sum_rad=turn,
              planning_ros_s=reply.result.planning_time.sec+reply.result.planning_time.nanosec*1e-9,
              wall_round_trip_ms=timings,median_round_trip_ms=statistics.median(timings),
              end_error_m=error,maximum_cost=max(costs,default=255),checked_samples=len(costs))
result['passed'] = reply.status==4 and len(points)>1 and error<=.2 and bool(costs) and max(costs)<253
(out/'metrics.json').write_text(json.dumps(result,indent=2))
(out/'path.json').write_text(json.dumps(points))
print(json.dumps(result),flush=True)
node.destroy_node()
rclpy.shutdown()
sys.exit(0 if result['passed'] else 1)

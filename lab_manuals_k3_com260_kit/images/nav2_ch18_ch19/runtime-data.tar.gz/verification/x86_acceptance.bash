#!/usr/bin/env bash
set -eo pipefail
run=$1
[[ $run =~ ^[[:alnum:]_-]+$ ]]
repo="$HOME/ROS2_RISCV_COM260_CH18_CH19"
workspace="$HOME/ros2_course_com260_ch18_ch19_humble_ws"
out="$workspace/runs/$run"
mkdir -p "$out"
exec > >(tee "$out/x86-build-and-examples.log") 2>&1
printf 'RUN_ID=%s HOST=x86\n' "$run"
date -u
uname -m
python3 "$workspace/fingerprint.py" "$repo" "$out/source-local.json" "$out/source-x86-before.json"
bash "$repo/course_support/k3_com260_kit/scripts/x86-ch18-ch19.bash" build
image=localhost/ros2-course-com260:ch16-ch17-nav2
podman image inspect --format '{{.Id}}' "$image"
podman run --rm --network none --cap-drop all --security-opt no-new-privileges \
  --volume "$workspace:/workspace:rw" --workdir "/workspace/runs/$run" "$image" \
  bash -c 'set -e; source /workspace/install/setup.bash
    for package in grid_path_planner hybrid_astar_planner path_optimizer dwa_planner rpp_controller; do
      printf "\n$ ros2 run %s %s\n" "$package" "$package"
      ros2 run "$package" "$package"
    done'
python3 "$workspace/fingerprint.py" "$repo" "$out/source-local.json" "$out/source-x86-after.json"
printf '\nX86_BUILD_AND_EXAMPLES_PASSED\n'

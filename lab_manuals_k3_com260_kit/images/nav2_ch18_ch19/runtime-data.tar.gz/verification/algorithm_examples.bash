#!/usr/bin/env bash
set -eo pipefail
run=$1
[[ $run =~ ^[[:alnum:]_-]+$ ]]
source "$HOME/ros2_course_com260_ch18_ch19_ws/board-env.bash"
out="$HOME/ros2_course_com260_ch18_ch19_ws/runs/$run"
cd "$out"
printf 'COM260 Kit | Chapters 18-19 | native C++17\nRUN_ID=%s\n' "$run"
date -u
uname -m
for package in grid_path_planner hybrid_astar_planner path_optimizer dwa_planner rpp_controller; do
  printf '\n$ ros2 run %s %s\n' "$package" "$package"
  ros2 run "$package" "$package"
  sleep 2
done
printf '\nAll five numerical examples exited 0.\n'
sleep 3

import json
import math
import os
from pathlib import Path
import subprocess
import time
import rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy
from nav_msgs.msg import Path as RosPath
from nav2_msgs.srv import GetCostmap

run=os.environ['COURSE_EVIDENCE_RUN']
out=Path.home()/'ros2_course_com260_ch18_ch19_ws/runs'/run/'grid-node'
out.mkdir(parents=True,exist_ok=True)
rclpy.init()
node=rclpy.create_node('grid_path_acceptance')
paths=[]
node.create_subscription(RosPath,'/planned_path',paths.append,QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
client=node.create_client(GetCostmap,'/global_costmap/get_costmap')
assert client.wait_for_service(timeout_sec=15)
request=client.call_async(GetCostmap.Request());rclpy.spin_until_future_complete(node,request,timeout_sec=10)
grid=request.result().map
meta=grid.metadata

def cost(x,y):
 gx=math.floor((x-meta.origin.position.x)/meta.resolution)
 gy=math.floor((y-meta.origin.position.y)/meta.resolution)
 return grid.data[gy*meta.size_x+gx] if 0<=gx<meta.size_x and 0<=gy<meta.size_y else 255

command=['ros2','run','grid_path_planner','grid_planner_node','--ros-args','-p','use_sim_time:=true','-p','goal_x:=1.0','-p','goal_y:=0.0']
with (out/'positive.log').open('w') as log:
 process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+30
 while time.monotonic()<deadline and (process.poll() is None or not paths):
  rclpy.spin_once(node,timeout_sec=.05)
 assert process.poll()==0 and paths,'C++ planner did not publish a successful path'
points=[(p.pose.position.x,p.pose.position.y) for p in paths[-1].poses]
costs=[]
for a,b in zip(points,points[1:]):
 steps=max(1,math.ceil(math.dist(a,b)/(meta.resolution/2)))
 for i in range(steps+1):costs.append(cost(*(a[j]+i/steps*(b[j]-a[j]) for j in (0,1))))
negative=subprocess.run(command[:-4],capture_output=True,text=True,timeout=30)
(out/'negative.log').write_text(negative.stdout+negative.stderr)
result=dict(run_id=run,frame=paths[-1].header.frame_id,positive_exit=process.returncode,path_points=len(points),end_error_m=math.dist(points[-1],(1,0)),max_path_cost=max(costs),checked_samples=len(costs),default_goal=[3,2],default_goal_cost=cost(3,2),negative_exit=negative.returncode)
result['passed']=result['positive_exit']==0 and result['end_error_m']<=.1 and result['max_path_cost']<253 and result['default_goal_cost']>=253 and result['negative_exit']==1
(out/'metrics.json').write_text(json.dumps(result,indent=2))
(out/'path.json').write_text(json.dumps(points))
print((out/'positive.log').read_text()+negative.stdout+negative.stderr)
print(json.dumps(result),flush=True)
node.destroy_node();rclpy.shutdown()
raise SystemExit(0 if result['passed'] else 1)

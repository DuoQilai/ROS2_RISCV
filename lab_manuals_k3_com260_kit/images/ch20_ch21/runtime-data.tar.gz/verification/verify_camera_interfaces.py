import array
import json
import math
import os
from pathlib import Path
import random
import signal
import struct
import subprocess
import sys
import time

import rclpy
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image, PointCloud2

out=Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
rclpy.init(); node=rclpy.create_node('camera_interface_fixture')
clouds=[]; matches=[]
node.create_subscription(PointCloud2,'/camera/points_sampled',clouds.append,10)
node.create_subscription(Image,'/orb/matches',matches.append,10)
color_pub=node.create_publisher(Image,'/camera/color/image_raw',10)
depth_pub=node.create_publisher(Image,'/camera/depth/image_raw',10)
info_pub=node.create_publisher(CameraInfo,'/camera/color/camera_info',10)
orb_pub=node.create_publisher(Image,'/camera/image_raw',10)
def spin(seconds):
    end=time.monotonic()+seconds
    while time.monotonic()<end: rclpy.spin_once(node,timeout_sec=.03)
def image(width,height,encoding,data,step):
    msg=Image(width=width,height=height,encoding=encoding,step=step,data=data)
    msg.header.frame_id='fixture_camera_optical_frame'; msg.header.stamp=node.get_clock().now().to_msg()
    return msg
results=[]
with (out/'camera.log').open('w') as camera_log, (out/'orb.log').open('w') as orb_log:
    processes=[subprocess.Popen(['ros2','run',pkg,pkg],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
               for pkg,log in [('camera_processor',camera_log),('orb_feature_extractor',orb_log)]]
    try:
        spin(2)
        info=CameraInfo(width=10,height=10,k=[10.,0.,5.,0.,10.,5.,0.,0.,1.])
        rgb=image(10,10,'bgr8',bytes([10,20,30])*100,30)
        for name,depths,expected in [
          ('four-points',[1.,2.,3.,4.],[[-.5,-.5,1.],[0.,-1.,2.],[-1.5,0.,3.],[0.,0.,4.]]),
          ('invalid-depth',[float('nan'),0.,6.,2.],[[0.,0.,2.]]),
          ('depth-limit',[0.,-1.,float('inf'),5.],[[0.,0.,5.]])]:
            clouds.clear(); values=[1.]*100
            for index,value in zip([0,5,50,55],depths): values[index]=value
            depth=image(10,10,'32FC1',array.array('f',values).tobytes(),40)
            deadline=time.monotonic()+8
            while not clouds and time.monotonic()<deadline:
                info_pub.publish(info); color_pub.publish(rgb); spin(.05); depth_pub.publish(depth); spin(.2)
            actual=[]; colors=[]
            if clouds:
                cloud=clouds[-1]; offsets={f.name:f.offset for f in cloud.fields}
                for i in range(cloud.width*cloud.height):
                    base=i*cloud.point_step
                    actual.append([struct.unpack_from('<f',cloud.data,base+offsets[axis])[0] for axis in ['x','y','z']])
                    colors.append(list(cloud.data[base+offsets['rgb']:base+offsets['rgb']+3]))
            passed=len(actual)==len(expected) and all(math.dist(a,b)<1e-6 for a,b in zip(actual,expected)) and all(c==[10,20,30] for c in colors)
            results.append(dict(case=name,expected=expected,actual=actual,bgr=colors,passed=passed))
            spin(.3)
        rng=random.Random(42)
        noise=bytes(rng.randrange(256) for _ in range(320*240*3))
        frame=image(320,240,'bgr8',noise,960)
        deadline=time.monotonic()+15
        while len(matches)<3 and time.monotonic()<deadline:
            orb_pub.publish(frame); spin(.5)
        logtext=(out/'orb.log').read_text()
        import re
        values=re.findall(r'ORB keypoints=(\d+) matches=(\d+)',logtext)
        passed=bool(matches and values) and all(m.width==640 and m.height==240 and m.encoding=='bgr8' for m in matches) and any(int(n)>100 and int(m)>100 for n,m in values)
        results.append(dict(case='orb-identical-frames',outputs=len(matches),keypoints_matches=values,passed=passed))
    finally:
        for process in processes:
            if process.poll() is None: os.killpg(process.pid,signal.SIGINT)
        for process in processes:
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(process.pid,signal.SIGKILL);process.wait()
exit_codes=[p.returncode for p in processes]
result=dict(scope='known RGB-D and ORB inputs; no physical depth camera or SLAM run',tests=results,
            exit_codes=exit_codes,passed=all(r['passed'] for r in results) and exit_codes==[0,0])
(out/'results.json').write_text(json.dumps(result,indent=2))
print((out/'camera.log').read_text(),flush=True);print((out/'orb.log').read_text(),flush=True)
print(json.dumps(result),flush=True)
node.destroy_node();rclpy.shutdown();sys.exit(0 if result['passed'] else 1)

import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

import rclpy
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovarianceStamped

mode, output, *command = sys.argv[1:]
out = Path(output)
out.mkdir(parents=True, exist_ok=True)
rclpy.init()
node = rclpy.create_node('behavior_acceptance')
samples = []
poses = []
node.create_subscription(PoseWithCovarianceStamped, '/amcl_pose',
    lambda msg: poses.append([time.monotonic(), msg.pose.pose.position.x, msg.pose.pose.position.y]),
    qos_profile_sensor_data)
def on_odom(msg):
    p, q, v = msg.pose.pose.position, msg.pose.pose.orientation, msg.twist.twist
    yaw = math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
    samples.append([time.monotonic(), p.x, p.y, yaw, v.linear.x, v.angular.z])
node.create_subscription(Odometry, '/odom', on_odom, qos_profile_sensor_data)
def spin(seconds):
    end = time.monotonic()+seconds
    while time.monotonic() < end:
        rclpy.spin_once(node, timeout_sec=0.03)
spin(3)
assert samples, 'No live /odom'
start = time.monotonic()
start_utc = datetime.now(timezone.utc).isoformat()
print('COMMAND='+ ' '.join(command), flush=True)
with (out/'client.log').open('w') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    signaled = False
    while process.poll() is None and time.monotonic()-start < 190:
        rclpy.spin_once(node, timeout_sec=0.03)
        moving = any(abs(s[5])>0.1 or abs(s[4])>0.02 for s in samples if s[0]>start)
        if mode.startswith('cancel') and moving and time.monotonic()-start > 3 and not signaled:
            os.killpg(process.pid, signal.SIGTERM if mode.endswith('term') else signal.SIGINT)
            signaled = True
        if mode in ('tree', 'negative-tree') and not signaled:
            status = 'SUCCESS' if mode == 'tree' else 'FAILURE'
            if '行为树结果: '+status in (out/'client.log').read_text():
                os.killpg(process.pid, signal.SIGINT)
                signaled = True
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGINT)
        spin(5)
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGKILL)
    code = process.wait()
spin(3)
recent = [s for s in samples if s[0]>time.monotonic()-1]
stopped = bool(recent) and all(abs(s[4])<0.02 and abs(s[5])<0.03 for s in recent)
motion = [s for s in samples if s[0]>start]
travel = sum(math.hypot(b[1]-a[1],b[2]-a[2]) for a,b in zip(motion,motion[1:]))
angle = sum(math.atan2(math.sin(b[3]-a[3]), math.cos(b[3]-a[3])) for a,b in zip(motion,motion[1:]))
passed = stopped and len(motion)>20
parameters = dict(part.split(':=', 1) for part in command if ':=' in part)
target = [float(parameters.get('x', 1)), float(parameters.get('y', 0))]
goal_error = math.hypot(poses[-1][1]-target[0], poses[-1][2]-target[1]) if poses else None
if mode=='spin': passed &= code==0 and abs(angle-1.57)<0.15
elif mode=='backup': passed &= code==0 and 0.12<travel<0.20
elif mode.startswith('cancel'):
    expected_exit = code==0 if mode=='cancel-tree-int' else code!=0
    passed &= expected_exit and signaled and (abs(angle)>0.1 or travel>0.05)
    if 'tree' in mode: passed &= '导航停止结果: CANCELED' in (out/'client.log').read_text()
elif mode=='negative': passed &= code!=0 and travel<0.03 and abs(angle)<0.03
elif mode=='negative-tree': passed &= code==0 and signaled and travel<0.03 and abs(angle)<0.03
elif mode in ('navigate', 'tree'): passed &= code==0 and goal_error is not None and goal_error<0.2 and poses[-1][0]>start
else: passed &= code==0
result = dict(mode=mode, start_utc=start_utc, end_utc=datetime.now(timezone.utc).isoformat(),
              command=command, exit_code=code, odom_samples=len(motion), travelled_m=travel,
              rotation_rad=angle, stopped=stopped, signal_sent=signaled, passed=bool(passed))
result['amcl_goal_error_m'] = goal_error
result['target_xy'] = target if mode in ('navigate', 'tree') else None
(out/'odom.csv').write_text('monotonic,x,y,yaw,vx,wz\n'+''.join(','.join(map(str,s))+'\n' for s in samples))
(out/'result.json').write_text(json.dumps(result, indent=2))
print((out/'client.log').read_text(), flush=True)
print(json.dumps(result), flush=True)
node.destroy_node()
rclpy.shutdown()
sys.exit(0 if passed else 1)

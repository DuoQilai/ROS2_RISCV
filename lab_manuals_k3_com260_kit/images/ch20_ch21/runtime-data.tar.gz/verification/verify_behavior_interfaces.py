import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import rclpy
from rclpy.action import ActionServer
from nav2_msgs.action import NavigateToPose, Spin, BackUp
from nav2_msgs.srv import ClearEntireCostmap
from std_msgs.msg import Float32

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
rclpy.init()
node = rclpy.create_node('behavior_interface_fixture')
received = []
settings = {}
clears = []
def execute(action, name):
    def callback(goal):
        request = goal.request
        if name == 'navigate':
            item = dict(action=name, x=request.pose.pose.position.x, y=request.pose.pose.position.y,
                        frame=request.pose.header.frame_id, tree=request.behavior_tree)
        elif name == 'spin':
            item = dict(action=name, yaw=request.target_yaw, seconds=request.time_allowance.sec)
        else:
            item = dict(action=name, x=request.target.x, speed=request.speed,
                        seconds=request.time_allowance.sec)
        received.append(item)
        count = sum(item['action'] == name for item in received)
        fail = settings.get('abort_all', False) or (settings.get('abort_first', False) and count == 1)
        goal.abort() if fail else goal.succeed()
        return action.Result()
    return callback
servers = [ActionServer(node, action, name, execute(action, short)) for action, name, short in [
    (NavigateToPose, '/navigate_to_pose', 'navigate'), (Spin, '/spin', 'spin'), (BackUp, '/backup', 'backup')]]
def clear(request, response):
    clears.append(time.monotonic())
    return response
service = node.create_service(ClearEntireCostmap, '/global_costmap/clear_entirely_global_costmap', clear)
battery = node.create_publisher(Float32, '/battery_status', 10)
results = []
def run(name, package, executable, parameters, config, expected_status=None):
    global settings
    settings = config
    received.clear(); clears.clear()
    command = ['ros2', 'run', package, executable]
    if parameters:
        command += ['--ros-args']
        for key, value in parameters.items(): command += ['-p', f'{key}:={value}']
    logfile = out / f'{name}.log'
    start = time.monotonic()
    signaled = False
    with logfile.open('w') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None and time.monotonic()-start < 25:
            if 'battery' in config: battery.publish(Float32(data=config['battery']))
            rclpy.spin_once(node, timeout_sec=0.05)
            if expected_status and not signaled and f'行为树结果: {expected_status}' in logfile.read_text():
                os.killpg(process.pid, signal.SIGINT); signaled = True
        timed_out = process.poll() is None
        if timed_out:
            os.killpg(process.pid, signal.SIGINT)
            until = time.monotonic()+3
            while process.poll() is None and time.monotonic()<until: rclpy.spin_once(node, timeout_sec=0.05)
        if process.poll() is None: os.killpg(process.pid, signal.SIGKILL)
        code = process.wait()
    result = dict(case=name, received=list(received), clear_calls=len(clears), exit_code=code,
                  duration_s=time.monotonic()-start, status_seen=signaled, timed_out=timed_out)
    result['passed'] = not timed_out and code == 0 and (expected_status is None or signaled)
    results.append(result)
    print(logfile.read_text(), flush=True)
    return result
r = run('spin', 'recovery_demo_cpp', 'spin_recovery', {}, {})
r['passed'] &= len(r['received'])==1 and abs(r['received'][0]['yaw']-1.57)<1e-5 and r['received'][0]['seconds']==5
r = run('backup', 'recovery_demo_cpp', 'backup_recovery', {}, {})
r['passed'] &= len(r['received'])==1 and abs(r['received'][0]['x']+.15)<1e-6 and abs(r['received'][0]['speed']-.05)<1e-6
for abort in [False, True]:
    r = run('strategy-'+str(abort), 'recovery_demo_cpp', 'recovery_strategy', {}, {'abort_all':abort})
    r['passed'] &= len(r['received'])==1 and r['received'][0]['action']=='spin'
    if abort: r['passed'] &= r['duration_s']>=1 and '等待 1.0 s' in (out/('strategy-'+str(abort)+'.log')).read_text()
r = run('tree-goal', 'behavior_tree_demo_cpp', 'bt_client', {'x':1.0,'y':2.0,'behavior_tree':'/fixture/tree.xml'}, {})
r['passed'] &= r['received']==[dict(action='navigate', x=1.0,y=2.0,frame='map',tree='/fixture/tree.xml')]
for name, config, status, count, clear_count in [
    ('battery-high', {'battery':.8}, 'SUCCESS', 1, 0),
    ('battery-low', {'battery':.1}, 'FAILURE', 0, 0),
    ('battery-threshold', {'battery':.2}, 'FAILURE', 0, 0),
    ('battery-missing', {}, 'FAILURE', 0, 0),
    ('navigate-retry', {'battery':.8,'abort_first':True}, 'SUCCESS', 2, 1),
    ('navigate-fails', {'battery':.8,'abort_all':True}, 'FAILURE', 2, 1)]:
    r=run(name, 'behavior_tree_demo_cpp', 'custom_behavior_tree', {'x':1.0,'y':0.0},config,status)
    r['passed'] &= len(r['received'])==count and r['clear_calls']==clear_count
    if count: r['passed'] &= '行为树结果: RUNNING' in (out/(name+'.log')).read_text()
result = dict(scope='known-input ROS action and service fixtures; no robot motion', tests=results,
              passed=all(r['passed'] for r in results))
(out/'results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
for server in servers: server.destroy()
node.destroy_node(); rclpy.shutdown()
sys.exit(0 if result['passed'] else 1)

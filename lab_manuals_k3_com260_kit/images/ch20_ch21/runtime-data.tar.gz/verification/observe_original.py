import csv, json, math, os, select, signal, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
import rclpy
from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy
from rclpy.time import Time
from nav_msgs.msg import Odometry, OccupancyGrid, Path as RosPath
from nav2_msgs.msg import Costmap
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from rosgraph_msgs.msg import Clock
from tf2_ros import Buffer, TransformListener

name=sys.argv[1]
batch=sys.argv[2]
limit=float(sys.argv[3]) if len(sys.argv)>3 else 600
case=sys.argv[4] if len(sys.argv)>4 else name
out=Path.home()/'ros2_course_com260_ch20_ch21_ws/runs'/batch/case
out.mkdir(parents=True,exist_ok=True)
rclpy.init();node=rclpy.create_node('original_lab_observer')
buffer=Buffer();listener=TransformListener(buffer,node)
sim_start=None;sim_elapsed=0.0
def clock(msg):
    global sim_start,sim_elapsed
    t=msg.clock.sec+msg.clock.nanosec*1e-9
    if sim_start is None:sim_start=t
    sim_elapsed=t-sim_start
start=time.monotonic();rows=[];events=[];plan_count=0;local_count=0;cmd_count=0;scan_count=0
latest=[None,None,None]; synthetic=[]; costmap=None; static_map=None; cost_trace=[]; injection_point=None
def nearby(data, width, height, origin, resolution, x, y):
    ix=math.floor((x-origin.x)/resolution);iy=math.floor((y-origin.y)/resolution)
    return max((data[yy*width+xx] for yy in range(iy-2,iy+3) for xx in range(ix-2,ix+3) if 0<=xx<width and 0<=yy<height),default=-1)
def map_received(msg):
    global static_map
    static_map=msg
def grid(msg):
    global costmap
    costmap=msg
    m=msg.metadata
    entry={"t":time.monotonic()-start,"fixture_target_cost":nearby(msg.data,m.size_x,m.size_y,m.origin.position,m.resolution,4.,0.)}
    if injection_point:
        entry["last_injected_point_cost"]=nearby(msg.data,m.size_x,m.size_y,m.origin.position,m.resolution,*injection_point)
    cost_trace.append(entry)
def odom(msg):
    global latest
    try:
        t=buffer.lookup_transform('map','base_link',Time()).transform
        q=t.rotation;latest=[t.translation.x,t.translation.y,math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))]
    except Exception:pass
    rows.append([time.monotonic()-start,msg.pose.pose.position.x,msg.pose.pose.position.y,msg.twist.twist.linear.x,msg.twist.twist.angular.z,*latest])
def plan(msg):
    global plan_count
    plan_count+=1
    if msg.poses:
        with (out/'plans.jsonl').open('a') as f: f.write(json.dumps({'t':time.monotonic()-start,'points':[[p.pose.position.x,p.pose.position.y] for p in msg.poses]})+'\n')
def local(msg):
    global local_count
    local_count+=1
def cmd(msg):
    global cmd_count
    cmd_count+=1
def scan(msg):
    global scan_count, injection_point
    scan_count+=1
    if len(msg.ranges)!=360 or abs(msg.range_max-3.5)>.001:return
    valid=[(i,d) for i,d in enumerate(msg.ranges) if .1<d<3.0]
    item={'t':time.monotonic()-start,'stamp':msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9,'frame':msg.header.frame_id,'beams':len(valid)}
    if valid and costmap:
        try:
            t=buffer.lookup_transform('map',msg.header.frame_id,Time()).transform
            q=t.rotation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
            i,d=valid[len(valid)//2];angle=msg.angle_min+i*msg.angle_increment+yaw
            x=t.translation.x+d*math.cos(angle);y=t.translation.y+d*math.sin(angle)
            m=costmap.metadata;ix=math.floor((x-m.origin.position.x)/m.resolution);iy=math.floor((y-m.origin.position.y)/m.resolution)
            cells=[costmap.data[yy*m.size_x+xx] for yy in range(iy-2,iy+3) for xx in range(ix-2,ix+3) if 0<=xx<m.size_x and 0<=yy<m.size_y]
            item.update(map_xy=[x,y],range=d,max_nearby_cost=max(cells,default=-1))
            if static_map:
                m=static_map.info
                item['static_nearby_max']=nearby(static_map.data,m.width,m.height,m.origin.position,m.resolution,x,y)
            if d<2.5:injection_point=[x,y]
        except Exception:pass
    synthetic.append(item)
node.create_subscription(Clock,'/clock',clock,qos_profile_sensor_data)
node.create_subscription(Costmap,'/global_costmap/costmap_raw',grid,10)
node.create_subscription(OccupancyGrid,'/map',map_received,QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
node.create_subscription(Odometry,'/odom',odom,qos_profile_sensor_data)
node.create_subscription(RosPath,'/plan',plan,10)
node.create_subscription(RosPath,'/local_plan',local,10)
node.create_subscription(Twist,'/cmd_vel',cmd,10)
node.create_subscription(LaserScan,'/scan_injected',scan,qos_profile_sensor_data)
command=['ros2','run','navigation_lab_cpp',name,'--ros-args','-p','use_sim_time:=true']
p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
log=(out/'client.log').open('w');timed_out=False;end=None;injector=None;injection_stopped=False
monitor=None
if case=='go_to_pose_demo':
    monitor=subprocess.Popen(['ros2','run','navigation_lab_cpp','nav_monitor','--ros-args','-p','use_sim_time:=true'],stdout=(out/'monitor.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
while end is None or time.monotonic()-end<3:
    rclpy.spin_once(node,timeout_sec=.03)
    if case in ['dynamic_patrol','recovery_scan'] and injector is None and (sim_elapsed>5 if case=='dynamic_patrol' else time.monotonic()-start>10):
        injector=subprocess.Popen(['ros2','run','navigation_lab_cpp','scan_injector','--ros-args','-p','use_sim_time:=true'],stdout=(out/'scan-injector.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
        events.append({'t':time.monotonic()-start,'sim_elapsed_s':sim_elapsed,'line':'INJECTION_START'})
    if injector and not injection_stopped and (sim_elapsed>70 if case=='dynamic_patrol' else time.monotonic()-start>180):
        os.killpg(injector.pid,signal.SIGINT);injector.wait(timeout=10);injection_stopped=True
        events.append({'t':time.monotonic()-start,'sim_elapsed_s':sim_elapsed,'line':'INJECTION_STOP'})
    if select.select([p.stdout],[],[],0)[0]:
        line=p.stdout.readline()
        if line:
            log.write(line);log.flush();print(line,end='',flush=True)
            events.append({'t':time.monotonic()-start,'pose':latest.copy(),'line':line.rstrip()})
    if p.poll() is not None and end is None:end=time.monotonic()
    if time.monotonic()-start>limit and p.poll() is None and not timed_out:
        os.killpg(p.pid,signal.SIGINT);timed_out=True
    if timed_out and time.monotonic()-start>limit+15 and p.poll() is None:
        os.killpg(p.pid,signal.SIGTERM)
    if time.monotonic()-start>limit+30:break
if injector and injector.poll() is None:
    os.killpg(injector.pid,signal.SIGINT);injector.wait(timeout=10)
monitor_exit=None
if monitor:
    os.killpg(monitor.pid,signal.SIGINT);monitor_exit=monitor.wait(timeout=10)
remainder=p.stdout.read() if p.poll() is not None else ''
log.write(remainder);log.close()
with (out/'odom.csv').open('w') as f:
    writer=csv.writer(f);writer.writerow(['wall_s','odom_x','odom_y','vx','wz','map_x','map_y','map_yaw']);writer.writerows(rows)
last=rows[-1][0] if rows else 0
tail=[r for r in rows if r[0]>=last-2]
summary={'name':name,'batch':batch,'command':command,'exit':p.poll(),'timed_out':timed_out,'duration_s':time.monotonic()-start,'odom_samples':len(rows),'plan_samples':plan_count,'local_plan_samples':local_count,'cmd_samples':cmd_count,'scan_samples':scan_count,'stopped':len(tail)>10 and all(abs(r[3])<.02 and abs(r[4])<.03 for r in tail),'end_map_pose':latest,'events':events,'finished_utc':datetime.now(timezone.utc).isoformat()}
(out/'synthetic-scan.json').write_text(json.dumps(synthetic,indent=2))
summary['synthetic_scan_samples']=len(synthetic)
summary['monitor_exit']=monitor_exit
summary['simulation_duration_s']=sim_elapsed
(out/'cost-trace.json').write_text(json.dumps(cost_trace,indent=2))
(out/'result.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='events'}),flush=True)
node.destroy_node();rclpy.shutdown()

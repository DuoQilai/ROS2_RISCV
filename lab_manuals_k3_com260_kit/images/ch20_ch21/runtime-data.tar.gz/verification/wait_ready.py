import json
import time
import rclpy
from rclpy.qos import qos_profile_sensor_data
from rclpy.time import Time
from lifecycle_msgs.srv import GetState
from nav_msgs.msg import Odometry
from rosgraph_msgs.msg import Clock
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer, TransformListener

rclpy.init()
node = rclpy.create_node('planning_readiness')
buffer = Buffer()
listener = TransformListener(buffer, node)
received = {}
def receive(topic):
    return lambda message: received.update({topic: time.monotonic()})
node.create_subscription(Clock, '/clock', receive('clock'), qos_profile_sensor_data)
node.create_subscription(Odometry, '/odom', receive('odom'), qos_profile_sensor_data)
node.create_subscription(LaserScan, '/scan', receive('scan'), qos_profile_sensor_data)
clients = {name: node.create_client(GetState, name+'/get_state')
           for name in ['/planner_server','/controller_server','/bt_navigator']}
begin = time.monotonic()
while time.monotonic()-begin < 80:
    rclpy.spin_once(node,timeout_sec=.1)
    if not all(name in received and time.monotonic()-received[name]<1 for name in ['odom','scan','clock']):
        continue
    if not buffer.can_transform('map','base_link',Time()):
        continue
    states = {}
    for name,client in clients.items():
        if not client.wait_for_service(timeout_sec=.1):
            break
        future = client.call_async(GetState.Request())
        rclpy.spin_until_future_complete(node,future,timeout_sec=2)
        if future.done() and future.result():
            states[name] = future.result().current_state.id
    if len(states)==3 and all(value==3 for value in states.values()):
        print(json.dumps({'ready':True,'states':states,'topics':list(received),'tf':'map->base_link'}),flush=True)
        break
else:
    raise RuntimeError('Nav2, TF or live sensors did not become ready')
node.destroy_node()
rclpy.shutdown()

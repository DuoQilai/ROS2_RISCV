import json
from pathlib import Path
import subprocess
import sys
import time

import rclpy
from rclpy.action import ActionServer, GoalResponse
from nav2_msgs.action import NavigateToPose

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
rclpy.init()
node = rclpy.create_node('scheduler_interface_fixture')
received = []
reject = False
def callback(name):
    def goal(request):
        received.append(dict(robot=name, x=request.pose.pose.position.x,
                             y=request.pose.pose.position.y, tree=request.behavior_tree))
        return GoalResponse.REJECT if reject and name=='robot3' else GoalResponse.ACCEPT
    return goal
def execute(goal):
    goal.succeed()
    return NavigateToPose.Result()
servers = [ActionServer(node, NavigateToPose, f'/{name}/navigate_to_pose', execute,
                        goal_callback=callback(name)) for name in ['robot1','robot2','robot3']]
tasks = out/'tasks.yaml'
tasks.write_text('''tasks:
  - {robot: robot1, x: 1.0, y: 0.0, recovery_strategy: aggressive}
  - {robot: robot2, x: 2.0, y: 1.0, recovery_strategy: default}
  - {robot: robot3, x: 0.0, y: 2.0}
  - {robot: robot4, x: 9.0, y: 9.0}
''')
results = []
for name, reject in [('accepted',False),('rejected',True)]:
    received.clear()
    command = ['ros2','run','multi_robot_scheduler','multi_robot_scheduler','--ros-args','-p',f'task_file:={tasks}']
    with (out/f'{name}.log').open('w') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        deadline=time.monotonic()+45
        while process.poll() is None and time.monotonic()<deadline:
            rclpy.spin_once(node, timeout_sec=0.03)
        if process.poll() is None: process.kill()
        code=process.wait()
    expected = [dict(robot='robot1',x=1.0,y=0.0,tree='aggressive_recovery.xml'),
                dict(robot='robot2',x=2.0,y=1.0,tree='default_navigation.xml'),
                dict(robot='robot3',x=0.0,y=2.0,tree='default_navigation.xml')]
    passed = sorted(received,key=lambda x:x['robot'])==expected and code==(1 if reject else 0)
    results.append(dict(case=name, received=list(received),exit_code=code,passed=passed))
    print((out/f'{name}.log').read_text(),flush=True)
result=dict(scope='known-input action interface fixture; no multi-robot motion',tests=results,
            passed=all(r['passed'] for r in results))
(out/'results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
for server in servers:server.destroy()
node.destroy_node();rclpy.shutdown()
sys.exit(0 if result['passed'] else 1)

import json
import hashlib
import math
from pathlib import Path
import sys
import time
from datetime import datetime, timezone

import rclpy
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image
from nav_msgs.msg import Odometry
from tf2_ros import Buffer, TransformListener

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
rclpy.init();node=rclpy.create_node('live_camera_acceptance')
mode=sys.argv[2] if len(sys.argv)>2 else 'all'
names=['info']+(['rgb'] if mode in ('all','rgb') else [])+(['matches'] if mode in ('all','orb') else [])
digests=set(); poses=[]
counts={name:0 for name in names};last={};first_stamp={};last_stamp={}
def observe(name):
    def callback(msg):
        counts[name]+=1
        last[name]=msg
        if isinstance(msg,Image): digests.add(hashlib.sha256(bytes(msg.data)).hexdigest())
        stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
        if name not in first_stamp:first_stamp[name]=stamp
        last_stamp[name]=stamp
    return callback
if 'rgb' in counts:node.create_subscription(Image,'/camera/image_raw',observe('rgb'),10)
if 'matches' in counts:node.create_subscription(Image,'/orb/matches',observe('matches'),10)
node.create_subscription(CameraInfo,'/camera/camera_info',observe('info'),qos_profile_sensor_data)
node.create_subscription(Odometry, '/odom', lambda msg: poses.append((msg.pose.pose.position.x, msg.pose.pose.position.y)), qos_profile_sensor_data)
buffer=Buffer();listener=TransformListener(buffer,node)
warmup=time.monotonic()
while not all(counts.values()) and time.monotonic()-warmup<60:
    rclpy.spin_once(node,timeout_sec=.05)
warmup_seconds=time.monotonic()-warmup
print('CAMERA_INPUTS_READY='+str(all(counts.values()))+' warmup_s='+str(round(warmup_seconds,3)),flush=True)
counts={key:0 for key in counts};last={};first_stamp={};last_stamp={}
digests.clear();poses.clear()
start=time.monotonic();begin=datetime.now(timezone.utc).isoformat()
while time.monotonic()-start<15:rclpy.spin_once(node,timeout_sec=.05)
transform=None
try:
    tf=buffer.lookup_transform('base_link','camera_link',rclpy.time.Time())
    transform={'parent':tf.header.frame_id,'child':tf.child_frame_id,
               'translation':[tf.transform.translation.x,tf.transform.translation.y,tf.transform.translation.z]}
except Exception as error:print('TF:',str(error))
metadata={}
for name,msg in last.items():
    metadata[name]={'width':msg.width,'height':msg.height,'frame':msg.header.frame_id,
                    'stamp_first':first_stamp[name],'stamp_last':last_stamp[name]}
    if isinstance(msg,Image):metadata[name]['encoding']=msg.encoding
    else:metadata[name]['K']=list(msg.k)
passed=all(counts[k]>2 for k in counts) and transform is not None
if 'rgb' in counts:passed=passed and metadata['rgb']['width']==320 and metadata['rgb']['height']==180
if 'matches' in counts:passed=passed and metadata['matches']['width']==640 and metadata['matches']['height']==180
passed=passed and metadata['info']['K'][0]>0 and metadata['info']['K'][4]>0
passed=passed and all(last_stamp[k]>first_stamp[k] for k in counts if k!='info')
travel=sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(poses,poses[1:]))
passed=passed and len(digests)>2 and travel>.1
result={'unique_images':len(digests),'odom_samples':len(poses),'odom_travel_m':travel,'scope':'live Gazebo RGB input, CameraInfo, TF and C++ ORB output; no depth camera or full SLAM',
        'mode':mode,'warmup_s':warmup_seconds,'start_utc':begin,'end_utc':datetime.now(timezone.utc).isoformat(),'counts':counts,'metadata':metadata,
        'transform':transform,'passed':bool(passed)}
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
node.destroy_node();rclpy.shutdown();sys.exit(0 if passed else 1)
